![Project Banner](banner.png)

# 🦖 Dinosaur AI — NeuroEvolution

[![Streamlit Dashboard](https://static.streamlit.io/badges/streamlit_badge_black_white.svg)](https://share.streamlit.io)
[![Python 3.10+](https://img.shields.io/badge/Python-3.10%2B-3776AB?logo=python&logoColor=white)](https://www.python.org/)
[![NEAT-Python](https://img.shields.io/badge/NEAT--Python-0.92-4CAF50)](https://neat-python.readthedocs.io/)
[![Play Live](https://img.shields.io/badge/PLAY-LIVE!-%23FFD700?style=for-the-badge&logo=googlechrome&logoColor=black)](https://Kasper166.github.io/DinosaurGameAI/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

A high-performance Pygame clone of the Chrome Dinosaur game where a neural network — evolved entirely through **NEAT (NeuroEvolution of Augmenting Topologies)** — learns to master survival in a dynamic, high-speed environment.

> [!IMPORTANT]
> **Performance Milestone:** The trained AI reaches a score of **100,000+** (Frames survived), clearing obstacles at maximum game velocity without human intervention.

![Demo GIF](demo.gif)

---

## ✨ Key Technical Highlights

- **🧠 Evolutionary Topology**: Unlike fixed architectures, NEAT evolves both the connection weights *and* the neural structure itself through mutations.
- **📈 Curriculum Learning**: Training starts with single obstacles and progressively introduces complex patterns (mid-air birds, fast-moving cactus clusters).
- **🕹️ Hybrid Gameplay**: Features interactive "Play vs AI" and "Spectator" modes for real-time performance evaluation.
- **📊 Professional Analytics**: A built-in Streamlit dashboard and in-game charts track fitness progression across generations.

### The Evolution Process (Full Generation Replay)
![Population Replay](replay.gif)

---

## 🎮 Play Modes

| Key | Mode | Description |
|-----|------|-------------|
| `SPACE` | **Manual** | You play solo — real Chrome Dino difficulty curve |
| `A` | **Play vs AI** | You and the best genome run side by side |
| `W` | **Watch AI** | The best genome plays autonomously (press `F` for fast-forward) |
| `D` | **Spectator** | Watch the entire last training generation evolve in real-time |

### Post-Game Analytics
After every game a built-in analytics screen shows:
- Your score vs the AI's all-time best and average fitness
- An inline bar chart of best/avg fitness per generation
- Which generation first surpassed your score

---

## 🧠 How the AI Works

### Neural Network Architecture
The AI processes the game state through a feed-forward network evolved via genetic algorithms. Below is how the "best" genome typically structures its decision-making pipeline:

```mermaid
graph LR
    subgraph Input ["Perception Layer"]
        dist[Distance Bucket]
        type[Obstacle Type]
        height[Bird Height]
        jump[Is Jumping?]
        phase[Jump Phase]
        duck[Is Ducking?]
    end

    subgraph Hidden ["Evolved Hidden Layer"]
        n1((Node 1))
        n2((Node 2))
    end

    subgraph Output ["Motor Cortex"]
        A[Run]
        B[Jump]
        C[Duck]
    end

    Input --> Hidden
    Hidden --> Output
    dist -.-> Output
    duck -.-> B
```

### NeuroEvolution of Augmenting Topologies (NEAT)

| Parameter | Value | Rationale |
|-----------|-------|-----------|
| **Population** | 450 Genomes | High diversity to prevent local minima. |
| **Fitness** | Total Frames Survived | Rewards pure survival. Capped at 100,000. |
| **Input Signals** | 6 Continuous Values | Minimalist state vector for faster convergence. |
| **Training Speed** | Delta +1.0 / 500f | Forces the AI to handle extreme velocities. |

**Dynamic Curriculum**: Low-height birds are introduced early in training (Gen 1-5). If the agent fails to learn the `Duck` action, it cannot survive past the first bird barrier, forcing the evolution of complex behaviors early on.

---

## 📈 Performance Analysis

Training this model results in a clear logarithmic growth curve as the population identifies the "Critical Threshold" for jumping over clustered obstacles.

![Training Progress](training_progress.png)

*The above chart displays the Fitness (Survival Time) across 50 generations, showing the exact moment the population cracked the "ducking" mechanic.*

---

## 🚀 Running Locally

### 1 · Install

```bash
git clone https://github.com/Kasper166/DinosaurGameAI
cd DinosaurGameAI
pip install -r requirements.txt
```

### 2 · Play (human mode)

```bash
python game.py
```

Controls: `↑` / `SPACE` jump · `↓` duck · `T` toggle AI ghost · `ESC` menu

### 3 · Watch the Trained AI

```bash
python game.py    # press [W] — Watch AI
```

Or watch the full last generation (Spectator mode):

```bash
python replay.py  # F = fast mode · D = debug overlay · ESC = quit
```

### 4 · Train Your Own AI

```bash
python neat_train.py
```

A live matplotlib dashboard opens showing fitness graphs per generation.
Checkpoints are saved every 10 generations; training auto-resumes from the latest.

---

## 🌐 Web & Dashboard

### Streamlit Analytics Dashboard

```bash
streamlit run streamlit_app.py
```

Shows training progress charts, leaderboard, stats cards, and run instructions.

**Deploy free in 60 seconds:**
1. Push repo to GitHub
2. Go to [share.streamlit.io](https://share.streamlit.io) → New app
3. Select repo → `streamlit_app.py` → Deploy ✅

### Browser-Playable Build (Pygbag)

The human-play mode can be packaged for the browser with Pygbag:

```bash
pip install pygbag
python -m pygbag --build main.py     # outputs build/web/
```

> **Note:** The AI inference modes (Watch AI, Spectator) are desktop-only because
> `neat-python` and `numpy` do not have official WebAssembly wheels.

Upload `build/web/` to [itch.io](https://itch.io) as an **HTML5 project** with
*"This file will be played in the browser"* enabled.

---

## 📁 Project Structure

```
DinosaurGameAI/
├── game.py              # Core Pygame engine — all play modes + analytics screen
├── main.py              # Async Pygbag entry point (browser build)
├── neat_train.py        # NEAT training loop + live matplotlib dashboard
├── replay.py            # Full-population spectator mode (standalone)
├── streamlit_app.py     # Web analytics dashboard
├── neat_config.txt      # NEAT hyperparameters
├── best_genome.pkl      # Saved best genome
├── best_genome_meta.json# Generation + fitness metadata
├── last_generation.pkl  # Last full generation (for Spectator mode)
├── training_history.json# Per-generation stats (auto-generated by training)
├── demo.gif             # Demo animation for README / dashboard
└── requirements.txt
```

---

## 🔧 Built With

- [Python 3](https://www.python.org/)
- [Pygame](https://www.pygame.org/)
- [NEAT-Python](https://neat-python.readthedocs.io/)
- [NumPy](https://numpy.org/)
- [Matplotlib](https://matplotlib.org/)
- [Streamlit](https://streamlit.io/)
- [Altair](https://altair-viz.github.io/)

---

*Created as a portfolio piece demonstrating Reinforcement Learning principles, evolutionary algorithms, and classical control environments in Python.*
