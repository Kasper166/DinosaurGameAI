import neat
import pickle
import numpy as np
import pygame
import imageio
from game import (DinoGame, Dino, GROUND_Y, DINO_H, SCREEN_WIDTH, SCREEN_HEIGHT,
                  WHITE, BLACK, GREY, FPS, PIXEL_SIZE,
                  DINO_PIXELS_RUN1, DINO_PIXELS_RUN2, DINO_PIXELS_DUCK1, DINO_PIXELS_DUCK2,
                  draw_pixel_art)

COLOR_ALIVE = (83,  83,  83)
COLOR_BEST  = (30,  120, 200)
COLOR_LAST  = (200, 80,  80)

def record_replay():
    config = neat.Config(
        neat.DefaultGenome,
        neat.DefaultReproduction,
        neat.DefaultSpeciesSet,
        neat.DefaultStagnation,
        "neat_config.txt"
    )

    if not (import_path := "last_generation.pkl"):
        return

    with open(import_path, "rb") as f:
        genomes = pickle.load(f)

    best_genome_id = max(genomes, key=lambda x: x[1].fitness or 0)[0]
    nets = [(neat.nn.FeedForwardNetwork.create(g, config), g, gid) for gid, g in genomes]
    n    = len(nets)

    master = DinoGame(render=False)
    master.reset()

    dinos      = [Dino() for _ in range(n)]
    alive      = [True] * n
    
    frames_img = []
    frames_count = 0
    max_frames = 600 # ~20 seconds of footage
    
    print(f"Recording replay of {n} dinosaurs...")

    while any(alive) and frames_count < max_frames:
        master_state = master.get_state()

        # Step each dino
        for i, (net, genome, gid) in enumerate(nets):
            if not alive[i]:
                continue
            dino = dinos[i]
            inputs = master.get_state(dino)
            output = net.activate(inputs)
            action = int(np.argmax(output))

            if action == 1: dino.jump()
            elif action == 2: dino.duck(True)
            else: dino.duck(False)
            dino.update()

            for obs in master.obstacles:
                if dino.get_rect().colliderect(obs.get_rect()):
                    alive[i] = False
                    break

        master.step(0)
        alive_count = sum(alive)

        # Draw to master.screen (which is a surface in headless mode)
        master.screen.fill(WHITE)
        pygame.draw.line(master.screen, BLACK, (0, GROUND_Y), (SCREEN_WIDTH, GROUND_Y), 2)
        for obs in master.obstacles:
            obs.draw(master.screen)

        # Draw dinos
        for i, dino in enumerate(dinos):
            if not alive[i]: continue
            _, _, gid = nets[i]
            # Simplifying coloring for GIF performance
            color = COLOR_BEST if gid == best_genome_id else COLOR_ALIVE
            grid = (DINO_PIXELS_DUCK1 if dino.frame == 0 else DINO_PIXELS_DUCK2) if dino.is_ducking \
                   else (DINO_PIXELS_RUN1 if dino.frame == 0 else DINO_PIXELS_RUN2)
            draw_pixel_art(master.screen, grid, dino.X, dino.y, color)

        # Capture frame every 2 frames
        if frames_count % 2 == 0:
            frame = pygame.surfarray.array3d(master.screen)
            frame = np.transpose(frame, (1, 0, 2))
            frames_img.append(frame)
        
        frames_count += 1
        if frames_count % 50 == 0:
            print(f"  Frame {frames_count}/{max_frames}...")

    print("Saving replay.gif...")
    imageio.mimsave("replay.gif", frames_img, fps=30)
    print("replay.gif saved!")

if __name__ == "__main__":
    record_replay()
